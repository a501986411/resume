<?php
	/**
	 *
	 * Created by PhpStorm.
	 * User: knight
	 * Date: 2017/8/9
	 * Time: 11:22
	 */

	namespace app\index\controller;


	class Resume
	{

		public function resume()
		{
			dump(input());die;
		}

		public function addResume()
		{
			dump(input());
		}

		public function showResume()
		{
			dump(input());
		}
	}