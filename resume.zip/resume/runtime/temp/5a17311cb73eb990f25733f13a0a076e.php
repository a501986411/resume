<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:67:"E:\project\resume\public/../application/index\view\index\Login.html";i:1502271368;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>简历共享-用户登录</title>
    <link rel="stylesheet" href="<?php echo UNIT_PATH; ?>layui/css/layui.css" media="all">
    <style>
        html,body{height: 100%;width: 100%;overflow: auto;}
        body{padding: 0;margin: 0;}
    </style>
</head>
<body >
    <div style="height: 100%;width: 100%;">
        <ul class="layui-nav" lay-filter="">
            <li class="layui-nav-item"><a href="">最新活动</a></li>
        </ul>
    </div>
</body>
<script src="<?php echo UNIT_PATH; ?>vue.min.js"></script>
<script src="<?php echo UNIT_PATH; ?>layui/layui.js"></script>
<script src="<?php echo STATIC_PATH; ?>index/js/load_layui_module.js"></script>
</html>